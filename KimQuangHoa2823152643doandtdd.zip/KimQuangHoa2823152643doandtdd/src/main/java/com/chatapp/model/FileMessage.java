package com.chatapp.model;

import java.awt.Color;
import java.awt.Desktop;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Arrays;
import javax.swing.AbstractAction;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTextPane;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.Element;
import javax.swing.text.Style;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;

public class FileMessage extends Message {
    String filename;
    byte[] file;

    public FileMessage(String filename, byte[] file, String sender, String receiver, boolean yourMessage) {
        super(sender, receiver, yourMessage);
        this.filename = filename;
        this.file = file;
    }

    @Override
    public void printMessage(String sender, JTextPane chatWindows) {
        StyledDocument doc = chatWindows.getStyledDocument();

        Style userStyle = doc.getStyle("User style");
        if (userStyle == null) {
            userStyle = doc.addStyle("User style", null);
            StyleConstants.setBold(userStyle, true);
        }

        try {
            if (yourMessage) {
                doc.insertString(doc.getLength(), "You: ", userStyle);
            } else {
                doc.insertString(doc.getLength(), sender + ": ", userStyle);
            }
        } catch (BadLocationException e) {
            e.printStackTrace();
        }

        Style linkStyle = doc.getStyle("Link style");
        if (linkStyle == null) {
            linkStyle = doc.addStyle("Link style", null);
            StyleConstants.setForeground(linkStyle, Color.BLUE);
            StyleConstants.setUnderline(linkStyle, true);
            StyleConstants.setBold(linkStyle, true);
            linkStyle.addAttribute("link", new HyperlinkListener(filename, file));
        }

        chatWindows.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                Element ele = doc.getCharacterElement(chatWindows.viewToModel2D(e.getPoint()));
                AttributeSet as = ele.getAttributes();
                HyperlinkListener listener = (HyperlinkListener) as.getAttribute("link");
                if (listener != null) {
                    listener.execute();
                }
            }

            @Override public void mousePressed(MouseEvent e) {}
            @Override public void mouseReleased(MouseEvent e) {}
            @Override public void mouseEntered(MouseEvent e) {}
            @Override public void mouseExited(MouseEvent e) {}
        });

        try {
            doc.insertString(doc.getLength(), "<" + filename + ">", linkStyle);
            doc.insertString(doc.getLength(), "\n", userStyle);
        } catch (BadLocationException e1) {
            e1.printStackTrace();
        }
    }

    class HyperlinkListener extends AbstractAction {
        String filename;
        byte[] file;

        public HyperlinkListener(String filename, byte[] file) {
            this.filename = filename;
            this.file = Arrays.copyOf(file, file.length);
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            execute();
        }

        public void execute() {
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setSelectedFile(new File(filename));
            int rVal = fileChooser.showSaveDialog(null);
            if (rVal == JFileChooser.APPROVE_OPTION) {
                File saveFile = fileChooser.getSelectedFile();
                try (BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(saveFile))) {
                    bos.write(this.file);
                } catch (IOException e) {
                    e.printStackTrace();
                }

                int nextAction = JOptionPane.showConfirmDialog(null, "Saved file to " + saveFile.getAbsolutePath() + "\nDo you want to open this file?", "Successful", JOptionPane.YES_NO_OPTION);
                if (nextAction == JOptionPane.YES_OPTION) {
                    try {
                        Desktop.getDesktop().open(saveFile);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }
}
