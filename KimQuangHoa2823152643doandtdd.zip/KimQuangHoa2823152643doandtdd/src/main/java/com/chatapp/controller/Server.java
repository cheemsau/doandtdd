package com.chatapp.controller;

import com.chatapp.helper.AccountDAO;
import com.chatapp.model.Account;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Server {

    static void LogOutAccount(Handler aThis) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    private Object lock;
    private ServerSocket server;
    private Socket socket;
    static ArrayList<Handler> clients = new ArrayList<>();
    Account account;
    AccountDAO accDAO;

    public Server() throws IOException {
        try {
            lock = new Object();
            server = new ServerSocket(9999);
            while (true) {
                socket = server.accept();
                DataInputStream dis = new DataInputStream(socket.getInputStream());
                DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
                String request = dis.readUTF();

                if (request.equals("Sign up")) {
                    String username = dis.readUTF();
                    String password = dis.readUTF();
                    Account acc = new Account(username, password, "");
                    if (!isExisted(username)) {
                        saveAccount(acc);
                        dos.writeUTF("Sign up successful");
                    } else {
                        dos.writeUTF("This username is being used");
                    }
                    dos.flush();
                } else if (request.equals("Log in")) {
                    String username = dis.readUTF();
                    String password = dis.readUTF();
                    if (isExisted(username)) {
                        Account client = getAccount(username);
                        if (client.getUserName().equals(username) && password.equals(client.getPassword())) {
                            Handler newHandler = new Handler(socket, client, lock);
                            clients.add(newHandler);
                            dos.writeUTF("Login successful");
                            dos.writeUTF(client.getAvatar());
                            dos.flush();
                            new Thread(newHandler).start();
                            updateOnlineUsers();
                        } else {
                            dos.writeUTF("Password is not correct");
                            dos.flush();
                        }
                    } else {
                        dos.writeUTF("This username does not exist");
                        dos.flush();
                    }
                } else if (request.equals("FileTransfer")) {
                    handleFileTransfer(dis);
                }
            }
        } catch (Exception ex) {
            System.err.println(ex);
        } finally {
            if (server != null) {
                server.close();
            }
        }
    }

    private void handleFileTransfer(DataInputStream dis) throws IOException {
    String sender = dis.readUTF();
    String receiver = dis.readUTF();
    String filename = dis.readUTF();
    int fileSize = dis.readInt();
    byte[] fileData = new byte[fileSize];
    dis.readFully(fileData);

    // Kiểm tra client đích có online không
    boolean found = false;
    for (Handler client : clients) {
        if (client.getUsername().equals(receiver)) {
            DataOutputStream dos = client.getOutput();
            dos.writeUTF("FileTransfer");
            dos.writeUTF(sender);
            dos.writeUTF(filename);
            dos.writeInt(fileSize);
            dos.write(fileData);
            dos.flush();
            found = true;
            System.out.println("Đã gửi file " + filename + " từ " + sender + " đến " + receiver);
            break;
        }
    }

    if (!found) {
        System.out.println("Người nhận " + receiver + " không online. Không thể gửi file.");
    }
}


    private String saveAccount(Account account) {
        accDAO = new AccountDAO();
        try {
            if (accDAO.saveAccountDAO(account)) {
                return "Successful account registration";
            }
        } catch (Exception ex) {
            Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "ERROR";
    }

    public boolean isExisted(String username) throws Exception {
        accDAO = new AccountDAO();
        account = accDAO.findAccountDAO(username);
        return account != null;
    }

    private Account getAccount(String username) {
        accDAO = new AccountDAO();
        try {
            account = accDAO.findAccountDAO(username);
        } catch (Exception ex) {
            Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
        }
        return account;
    }

    public static void updateOnlineUsers() {
        String message = " ";
        if (!clients.isEmpty()) {
            for (Handler client : clients) {
                message += "," + client.getUsername();
            }
            message = message.substring(2);
            for (Handler client : clients) {
                try {
                    if (client.getOutput() != null) {
                        client.getOutput().writeUTF("Online users");
                        client.getOutput().writeUTF(message);
                        client.getOutput().flush();
                    }
                } catch (IOException e) {
                    System.out.println("Error");
                }
            }
        }
    }
}
